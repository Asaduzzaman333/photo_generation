
import React from 'react';

export const UploadIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
  </svg>
);

export const MagicWandIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.25278C12 6.25278 12 2.75 12 2.75C12 2.75 11.1213 3.62868 10.2929 4.45711C9.46447 5.28553 6.25278 8.5 6.25278 8.5L15.5 17.7472L19.25 14L12 6.25278Z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6.25 8.5L4 10.75L2.75 9.5L5 7.25L6.25 8.5Z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.5 17.75L17.75 20L19 21.25L21.25 19L20 17.75L17.75 15.5L15.5 17.75Z" />
    </svg>
);


export const DownloadIcon: React.FC = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);
