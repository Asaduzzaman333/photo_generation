
import React from 'react';
import type { BackgroundOption } from '../types';

interface OptionSelectorProps {
  title: string;
  options: BackgroundOption[];
  selectedOption: BackgroundOption;
  onSelect: (option: BackgroundOption) => void;
}

export const OptionSelector: React.FC<OptionSelectorProps> = ({ title, options, selectedOption, onSelect }) => {
  return (
    <div>
      <h3 className="text-xl font-semibold text-center mb-5">{title}</h3>
      <div className="flex flex-wrap justify-center gap-3">
        {options.map((option) => (
          <button
            key={option.id}
            onClick={() => onSelect(option)}
            className={`px-5 py-2.5 text-sm font-medium rounded-full transition-all duration-300 ease-in-out transform hover:scale-105 ${
              selectedOption.id === option.id
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                : 'bg-white/10 text-gray-300 hover:bg-white/20'
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};
