
import React, { useState, useRef } from 'react';
import { UploadIcon } from './icons';

interface ImageUploaderProps {
  title: string;
  onImageUpload: (base64: string) => void;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ title, onImageUpload }) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImagePreview(base64String);
        onImageUpload(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div
      className="bg-white/5 backdrop-blur-sm border border-dashed border-white/20 rounded-2xl p-6 text-center flex flex-col items-center justify-center cursor-pointer transition-all duration-300 hover:bg-white/10 hover:border-white/30 aspect-square"
      onClick={handleUploadClick}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
      />
      {imagePreview ? (
        <div className="relative w-full h-full">
            <img src={imagePreview} alt="Preview" className="w-full h-full object-contain rounded-lg" />
            <button
                onClick={(e) => {
                    e.stopPropagation();
                    handleUploadClick();
                }}
                className="absolute bottom-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm hover:bg-black/70 transition-colors"
            >
                Change
            </button>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center gap-4 text-gray-400">
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center">
            <UploadIcon />
          </div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
          <p>Click to browse or drag & drop</p>
        </div>
      )}
    </div>
  );
};
