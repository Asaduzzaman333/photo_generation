
export interface BackgroundOption {
  id: string;
  label: string;
  prompt: string;
}
